<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Betting extends Model
{
    use HasFactory;
    protected $table = "bettings";

    protected $fillable = ['country_id','logo','name','description','bonus','turnover','min_odds','slug','website_url','review'];

   
    public function country()
    {
        return $this->hasOne(Country::class,'id', 'country_id');
    }
    public function feature(){
    
        return $this->hasMany(Feature::class, 'betting_id', 'id');
    }
}
