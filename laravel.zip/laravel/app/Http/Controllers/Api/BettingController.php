<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\BettingResource;
use Illuminate\Http\Request;
use App\Models\Betting;
use Illuminate\Support\Str;
use App\Http\Requests\BettingRequest;



class BettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $bettings = Betting::all();
      
        //  dd("test");
        if($bettings){
            $res = [
              'status' => 200,
              'success' => true,
              'message' => "Betting data fetched successfully!",
              'result' => BettingResource::collection($bettings),
              ];
              
              return response()->json($res, 200);
          }
          else{
  
              $res = [
                  'status' => 404,
                  'success' => true,
                  'message' => "Something went wrong!",
                  'result' => null,
                  ];
                  
                  return response()->json($res, 404);
              }   
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BettingRequest $request)
    {   
     //dd($request->all());
     //return $request->all();
   
      if($request->file('logo')) {
        $logo = $request->file('logo')->store('public/betting');
        $logo = 'betting/' . pathinfo($logo)['basename'];
        
    } else {
        $logo = '';
    }

        $bettings = Betting::create([
             
            
            'logo' => $logo,
            'name' => $request->name,
            'description' => $request->description,
            'bonus' => $request->bonus,
            'turnover' => $request->turnover,
            'min_odds' => $request->min_odds,
            'slug' => Str::slug($request->name),
            'website_url' => $request->website_url,
            // 'review' => $request->review,
            'country_id' => $request->country_id,

           
        
          ]);
          if($bettings){
          $res = [
            'status' => 200,
            'success' => true,
            'message' => "Betting Data added successfully!",
            'result' => $bettings,
            ];
            
            return response()->json($res, 200);
        }
        else{

            $res = [
                'status' => 404,
                'success' => true,
                'message' => "Something went wrong!",
                'result' => null,
                ];
                
                return response()->json($res, 404);
            }   
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function get_football()
    {
        $bettings = Betting::all();
      
        //  dd("test");
        if($bettings){
            $res = [
              'status' => 200,
              'success' => true,
              'message' => "Football data fetched successfully!",
              'result' => $bettings,
              ];
              
              return response()->json($res, 200);
          }
          else{
  
              $res = [
                  'status' => 404,
                  'success' => true,
                  'message' => "Something went wrong!",
                  'result' => null,
                  ];
                  
                  return response()->json($res, 404);
              }   
    }


    public function add_football(Request $request)
    {   
     //dd($request->all());
     //return $request->all();
   
      if($request->file('logo')) {
        $logo = $request->file('logo')->store('public/football');
        $logo = 'football/' . pathinfo($logo)['basename'];
        
    } else {
        $logo = '';
    }

        $bettings = Betting::create([
             
            
            'logo' => $logo,
            'name' => $request->name,
            'description' => $request->description,
            'bonus' => $request->bonus,
            'feature' => $request->feature,
            'slug' => Str::slug($request->name),
            'website_url' => $request->website_url,
            'review' => $request->review,
            'country_id' => $request->country_id,

           
        
          ]);
          if($bettings){
          $res = [
            'status' => 200,
            'success' => true,
            'message' => "Football Data added successfully!",
            'result' => $bettings,
            ];
            
            return response()->json($res, 200);
        }
        else{

            $res = [
                'status' => 404,
                'success' => true,
                'message' => "Something went wrong!",
                'result' => null,
                ];
                
                return response()->json($res, 404);
            }   
    }

   
}
