<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\FeatureResource;
use App\Models\Feature;

class BettingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $features = Feature::where('betting_id',$this->id)->get();
       return [
        
        'id' => $this->id,
        'name' => $this->name,
        'logo' => $this->logo,
        'description' => $this->description,
        'bonus' => $this->bonus,
        'turnover' => $this->turnover,
        'min_odds' => $this->min_odds,
        'slug' => $this->slug,
        'website_url' => $this->website_url,
        'review' => $this->review,
        'feature' => FeatureResource::collection($features),
        'country_id ' => $this->country_id?$this->country->name:"",
      
      
      ];
    }
}
