<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\BettingController;
use App\Http\Controllers\Api\FeatureController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::resource('bettings', BettingController::class);
Route::get('get_football', [BettingController::class, 'get_football']);
Route::post('add_football',[BettingController::class, 'add_football']);

Route::resource('features', FeatureController::class);


